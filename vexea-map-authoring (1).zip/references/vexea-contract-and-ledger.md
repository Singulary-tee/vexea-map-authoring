# VEXEA Contract, Ledger, and Slice Gate

## Load this reference when

Load this file before opening or editing the VEXEA map-authoring bench, changing semantic records, selecting a slice, or interpreting a visual defect. The map is not a blank canvas: preserve reusable runtime truth and change presentation through a traceable plan.

## Stage 0: establish truth

Read, in order, `ARCHITECTURE.md`, `GAMEPLAY.md`, `GAMEMODE_CONFIG.md`, the current exported gameplay-first specification, `client/map-authoring-output/industrial-grammar.md`, and `client/map-authoring-output/vexea_map_01_environment_kit.plan.md`. Then inventory the actual scripts and hooks before authoring.

Write `client/map-authoring-output/authoring-ledger.json`. Record each source path, content hash, semantic contract values, player reference and capsule constants, current zone/connector graph, reusable assets and prepared manifests, current known failures, selected slice, and the skill version. Downstream artifacts record the ledger hash. Load values programmatically where possible; do not duplicate constants as literals.

The active gameplay contract remains authoritative: seven zones, existing zone/connector semantics, 5–10 players, 480 seconds, eight-second commander cadence, far-end objective semantics, drone deployment and kill-zone rules, camera/destructible cues, spawn/respawn and navmesh meaning. Visual work may surround or explain these records but may not silently rewrite them.

## Select one representative slice

Select two adjacent zones and their connector from the current semantic graph. Choose a slice that exercises the intended authoring system: insertion/staging, a readable route, at least one service or pressure space, a meaningful height relationship, deliberate cover, one drone deployment/kill-zone read, a surveillance cue, and a destination or approach beat. Do not select a convenient empty area merely because it is easy to dress.

Write `slice-contract.json` with zone IDs, connector ID, spatial roles, route endpoints, objective relationship, deployment/kill-zone references, cover obligations, vertical obligations, player calibration values, fixed camera suite, and hashes of the source contracts. Export the current semantic baseline and save its hash before visual dressing.

## Hard sequencing rules

1. Freeze semantic truth and the selected slice before geometry.
2. Build and validate the ground datum before masses or props.
3. Place real-depth masses and route boundaries before detail.
4. Run calibration, contact, overlap, and depth gates before materials and background dressing.
5. Author PvE space and cover against the actual graph and drone roles.
6. Capture forensic views and final views only after world-space gates are green.
7. Measure performance after visual quality is established; optimize with LOD, culling, paging, instancing, and merging rather than degrading to ugly low-poly substitutes.
8. Permit campus expansion only after the slice evidence bundle, critic review, and complete regression bundle pass.

## Reuse table

Declare the existing system or new work for every class before authoring:

| Class | Default treatment | Admission evidence |
|---|---|---|
| Roads, sidewalks, curbs, drainage, long utilities | Procedural or hybrid | Profile, joints, support/contact, material family, segment plan |
| Architectural shells and service buildings | Volumetric procedural/hybrid | Footprint, real depth, side/rear/roof closure, openings, height role |
| Vehicles and complex machinery | Prepared sourced GLB | Provenance, Blender manifest, uniform scale, contact plane, LOD, context tag |
| Repeated structural modules | Instanced or merged family | Stable module ID, socket/host, variation seed, batch/page assignment |
| Gameplay objects | Existing semantic record plus visual explanation | Stable binding and gameplay-preservation diff |
| Background dressing | Last, paged and camera-justified | Depth-band role, bounds, material family, no unreadable pile |

## Expansion gate

Write `expansion-gate-report.json`. Expansion is blocked unless the slice has: a reproducible plan and semantic baseline; passing calibration, contact, overlap, scale/traversal, facade-depth, verticality, PvE-space, and camera reports; measured performance; fixed captures; Ox Alpha approval of the evidence; and green gameplay/export/runtime/mobile/Blender/build regressions. Any semantic drift requires a new baseline decision, not an undocumented patch.

## Fail-closed behavior

Stop when a source value is ambiguous, a placement lacks an owner or stable ID, a geometry family is still a primitive placeholder, a report is missing, a gate has no measured pass condition, a critic returns `REVISE`, or a repeated failure points to a generator/grammar problem. Return to the owning stage. Never hide defects with fog, framing, culling, or a lower LOD.

## References

[1]: https://github.com/OndrejNepozitek/Edgar-DotNet "Edgar-DotNet graph-first layout"
[2]: https://github.com/majidmanzarpour/threejs-procedural-dungeon "Three.js procedural layout pipeline"
[3]: https://github.com/linegel/threejs-complete-set-of-skill "Procedural buildings and cities compiler workflow"
