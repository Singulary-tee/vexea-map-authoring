# PvE Space, Cover, Verticality, and Surveillance

## Load this reference when

Load this file after the semantic slice graph and primary architecture exist, before placing combat cover, deployment structures, surveillance cues, or decorative service clutter. It keeps visual authoring tied to player decisions and the actual VEXEA drone roster.

## Combat-space matrix

Write `combat-space-matrix.json` with one record per engagement space. Include owning zone/connector, player entry/exit, cover anchors and height classes, hard/soft cover, exposure lanes, retreat and rotation routes, drone approach lanes, surveillance sightlines, deployment envelope, kill-zone volume, vertical roles, destructible cues, and the intended player decision.

A cover object is admitted only if it creates a decision: break a sightline, create a firing position, offer a retreat, separate an approach, allow a flank, or expose a meaningful tradeoff. It must be reachable or usable by the actual player capsule, must not seal the route accidentally, and must not be moved by a generic overlap solver after gameplay bindings are frozen.

## Drone-role mapping

| Drone role | Space requirement | Authoring check |
|---|---|---|
| Rotary harassment | Readable exposure, hard-cover breaks, retreat/rotation options | Verify at least one exposed lane and one reachable hard-cover alternative. |
| Bomber pressure | Denial choices, safe/unsafe pockets, visible deployment logic | Verify bomb pressure cannot leave players with one arbitrary escape and that kill-zone cues are legible. |
| Wheeled drone | Defendable holding position, lanes and cover around the position | Verify approach is readable and not blocked by decorative clutter. |
| Robot dog | Pursuit, flank, and traversal space | Verify capsule/drone clearance along at least two pursuit directions. |
| Humanoid pressure | Hard/soft cover rhythm and short-range pressure | Verify cover is not all-hard or all-open; provide readable risk/reward movement. |
| Fixed-wing event | Legible open-air risk space and shelter choices | Verify roofs/gantries do not accidentally turn the open-zone event into an invisible rule. |
| Reconnaissance | Long sightline plus disengagement/occlusion options | Verify surveillance is readable through cameras, masts, lights, or access panels rather than sci-fi architecture. |

## Deployment and kill zones

Keep gameplay volumes authoritative. Dress them with visible operational explanations: enclosure, service access, fixed turret or emplacement context, barriers, cameras, warning lights/signage, and a predictable entry/exit relationship. A closed kill zone must look closed for a reason, not like a random dark box.

For each deployment area, show a plausible source/transition path so drones do not appear to pop into existence. The kill-zone volume must intersect the intended approach or staging geometry and must be validated against the semantic export. Do not move or enlarge gameplay volumes merely to make a screenshot look balanced.

## Vertical play

Assign vertical roles before props: raised apron, stair/ramp route, catwalk/service access, roofline landmark, high surveillance point, ground-level hard cover, and open-air risk. Every elevation change needs a support/contact contract and a reason tied to route, cover, landmark, service function, or drone behavior. Add no disconnected floating platform.

Use the 1.8 m player and capsule to test stair/ramp clearance, headroom, cover height, landing size, and line-of-sight changes. At least one slice camera and one side/section view must prove the vertical relationship is readable. Verticality that exists only in hidden geometry or an unreachable roof does not count.

## Surveillance and practical cues

Surveillance should read through ordinary industrial infrastructure: cameras on brackets, poles, access-control boxes, masts, lights, cables, and sightline targets. Bind every cue to a target or zone role. The architecture stays contemporary; intelligence is expressed through coverage, behavior, destructibility, and practical devices.

## Route and cover probes

For every accepted approach route, run a player-height capture and a capsule/path probe. Record whether the next cover choice, retreat, deployment cue, and destination are visible or inferable. If a route is visually full but tactically empty, remove decoration and add an actual decision structure. If a route has one path and no meaningful alternate, return to the zone/connector plan.

## Gate outputs

Write `cover-bindings.json`, `verticality-report.json`, and route/cover captures. The report must list stable IDs and measured clearances. Fail the slice if any engagement space has zero deliberate cover, no retreat/rotation option, an unbound deployment/kill-zone, a route-blocking cover object, or a vertical element without support and purpose.

## References

[1]: https://github.com/Singulary-tee/vexea-international "VEXEA project repository"
[2]: https://github.com/OndrejNepozitek/Edgar-DotNet "Graph-driven semantic layout"
[3]: https://github.com/majidmanzarpour/threejs-game-skills "Three.js game-authoring and adversarial review patterns"
