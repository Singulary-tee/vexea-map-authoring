# Industrial Grammar and Architecture

## Load this reference when

Load this file when selecting procedural, hybrid, or sourced treatment; authoring ground, roads, sidewalks, buildings, utilities, service yards, thresholds, or plant structures; or deciding whether a visible module is finished enough for a promoted slice.

## Treatment rule

Choose the representation that preserves the required silhouette and construction logic at the intended camera distance:

| Need | Default treatment | Why |
|---|---|---|
| Long, dimension-critical runs | Procedural/hybrid | Keeps roads, curbs, sidewalks, pipe racks, fences, and service bands continuous and correctly sized. |
| Complex manufactured silhouette | Prepared sourced GLB | Vehicles and machinery are expensive to author convincingly; preserve their high-quality appearance through Blender cleanup, uniform scale, LOD, and context placement. |
| Broad surface response | PBR material family | Use verified color/normal/roughness or equivalent maps on a real surface; do not use texture to disguise a paper plane. |
| Repeated structural family | Parameterized procedural module, instanced or merged | Own variation through a seed and frame; avoid dozens of unrelated hand-built boxes. |
| Temporary blockout | Primitive | Label and isolate it. A visible primitive placeholder blocks promotion. |

## Volumetric building procedure

Start from a semantic mass record with footprint, height role, interior/solid status, road interface, service interface, and page ID. Emit a volume with front, side, rear, roof, and ground interfaces. Resolve shared walls and exposed boundaries before placing surface modules.

A facade is not a building. Require measurable shell/depth behind any visible facade, side/rear closure, roof/parapet termination, ground seating, openings, service access, and shadow-catching reveals. Windows, garage bays, doors, louvers, stairs, catwalks, and canopies attach to the mass frame and cannot float as a second scene. Use section and side views to reject thin planes.

Build in this order: mass -> openings and bays -> structural frame -> service access -> roof/parapet -> utility attachments -> materials -> controlled wear. A module that cannot state its owner, frame, support, and termination is not placed.

## Procedural family grammar

For each final family define:

1. **Profile:** cross-section, radius/edge treatment, thickness, seam interval, and cap/end treatment.
2. **Construction:** how pieces join, overlap deliberately, support neighboring pieces, meet ground, and terminate at equipment or structure.
3. **Material:** base material, roughness response, edge/weathering behavior, and permitted variation range.
4. **Variation:** seeded length, bay rhythm, offset, wear, or part choice within a constrained family; never arbitrary noise.
5. **Distance tiers:** LOD0 detail for close views, simplified but recognizable LOD1, and cull/merge/page rules for distant views.
6. **Evidence:** untextured silhouette, player-height view, side/section view, contact/overlap report, and final material capture.

Roads and sidewalks must be segmented construction: driving surface, edge/curb profile, pedestrian slab, drainage/inlet logic, joints, patches, and transitions at ramps, yards, and thresholds. Avoid a single broad gray rectangle with thin decorative lines.

Utilities must explain the place: poles have bases and cross-members; pipe racks have supports and bends; cable trays have hangers and equipment destinations; canopies have posts, brackets, and roof drainage; beams span named hosts or terminate in a structural frame. Long elements without supports are rejected.

## Height rhythm and depth

Assign height roles before detail: low arrival/service edge; mid-height pressure or warehouse mass; one or more taller plant, tank, stair, tower, or stack anchors; and a readable distant termination. Introduce grade changes, raised aprons, stairs, ramps, roof/service access, and vertical cover only when supported by a route, service function, landmark, tactical choice, or drone behavior. No floating platforms or random height noise.

For every slice camera, record at least one low/mid/high silhouette relationship and one usable player-height vertical transition. If all masses read as one height band, return to the mass plan.

## Primitive rejection

A box/cylinder is allowed only when it is a temporary blockout, hidden collision/support proxy, intentionally simple subcomponent inside a finished assembly, or explicitly named low-frequency background element. Before promotion, run a primitive census by stable ID. Any visible primitive that is standing in for a building, sidewalk, road, utility run, cover object, or service structure must either be replaced by its family grammar or be explicitly justified in the plan and accepted by the critic.

Do not apply bevels, random color changes, or PBR maps as a substitute for missing construction. If a family still requires those tricks to look finished, reject the family and redesign its profile/assembly.

## Coherent family integration

Choose a material and weathering vocabulary per architectural family. Sourced GLBs, procedural geometry, lights, and atmosphere must share scale, roughness/value ranges, contact shadows, weathering direction, and construction interfaces. A hero GLB beside visibly provisional geometry is an asset-flip failure. Improve or remove the neighboring context; do not lower the hero asset.

## References

[1]: https://github.com/linegel/threejs-complete-set-of-skill "Procedural buildings and cities compiler workflow"
[2]: https://github.com/achrefelouafi/BuildingGeneratorThreeJS "BuildingGeneratorThreeJS parameterized and instanced kit"
[3]: https://github.com/StarKnightt/sedona-sunset "Sedona Sunset corridor and terrain construction"
[4]: https://github.com/StarKnightt/night-street "night-street placement and material construction"
