#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: run-vexea-authoring-gates.sh --plan PATH --reports-dir PATH [--self-test]

The runner validates authoring artifacts. It does not author or silently repair
geometry. Project-specific gameplay/export/runtime/mobile/build regressions must
still be invoked from the target repository's established command sequence.
EOF
}

plan=''
reports=''
self_test=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --plan) plan="$2"; shift 2 ;;
    --reports-dir) reports="$2"; shift 2 ;;
    --self-test) self_test=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

root="$(cd "$(dirname "$0")/.." && pwd)"
if [[ "$self_test" == 1 ]]; then
  python3 "$root/scripts/validate-vexea-scene-gates.py" --self-test
fi

if [[ -z "$plan" || -z "$reports" ]]; then
  echo 'plan and reports-dir are required; refusing to run a partial gate' >&2
  usage >&2
  exit 2
fi

plan_report="$reports/plan-validation-report.json"
python3 "$root/scripts/validate-vexea-authoring-plan.py" "$plan" --report "$plan_report"
python3 "$root/scripts/validate-vexea-scene-gates.py" --reports-dir "$reports" --output "$reports/scene-gates-report.json"

cat > "$reports/authoring-gate-manifest.json" <<EOF
{
  "pass": true,
  "plan": "$plan",
  "reports_dir": "$reports",
  "plan_report": "$plan_report",
  "scene_report": "$reports/scene-gates-report.json",
  "note": "Project gameplay/export/runtime/mobile/Blender/build regressions remain required and are not replaced by this artifact gate."
}
EOF
printf '%s\n' "VEXEA authoring artifact gates passed: $reports"
