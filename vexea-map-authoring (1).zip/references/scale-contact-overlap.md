# Scale, Contact, Attachment, and Overlap Gates

## Load this reference when

Load this file before placing any mass, prop, utility, vehicle, cover object, or imported GLB, and after any transform, ground, footprint, or socket change. These checks measure world-space truth, not whether fog or a locked camera hides a defect.

## Calibration fixture

Build one persistent bench fixture from imported VEXEA constants: a 1.8 m human silhouette, exact player capsule, eye-height datum, capsule-radius ring, 1 m grid/10 m majors, door gauge, stair/ramp gauge, cover-height bands, vehicle-scale board, and camera-height marker. Store it as a reusable scene object and include its hash in every calibration report.

For every asset before placement, measure the world bounding box and compare it with the fixture and its class specification. Perform one uniform scale correction in the portable Blender preparation pipeline, not ad hoc scene stretching. Block assets with unknown units, non-uniform baked transforms, missing contact metadata, or no real-world dimension evidence. Vehicles and machinery are sourced GLBs: check scale, prepared origin/contact plane, LOD, provenance, and context only; never author tire internals.

Emit `calibration-report.json` keyed by stable placement ID. Include source dimensions, resolved dimensions, uniform factor, calibration reference, intended class, contact class, and pass/blocked state. Run player-height eye-level, capsule top-down, and section views for the slice.

## Ground/contact pass

Run after ground and route surfaces are frozen and after final transforms are applied, before semantic export and before polish. Resolve the final LOD0 render meshes and tagged ground surfaces; a future BVH backend may accelerate the query, but the report must describe which geometry was tested.

Classify every visible solid as `GROUNDED`, `SUPPORTED`, or `SUSPENDED`. For grounded/supported objects, probe the centroid plus base-perimeter samples or a bounded grid, not the centroid alone. Record hit surface ID, signed gap/sink, and the support host. For suspended utilities, signs, gantries, and overheads, require a machine-readable anchor contract naming host IDs, endpoint sockets, attachment points, and player/drone clearance. An unanchored elevated object is floating.

Snap only within the declared contact tolerance and re-probe once. If probes disagree, no host exists, or repeated solving cannot converge, return the object to its placement/grammar stage. Do not silently sink a mis-scaled GLB, hide a gap with fog, or auto-snap a deliberate ramp/debris composition without an explicit contract.

Emit `contact-report.json` with object ID, zone/page, support class, probe coordinates, hit surface, signed offsets, classification, anchor status, tunable snapshot, and scene hash. Add fixtures: flush cube, lifted cube, sunk curb, sloped/ramp object, valid suspended pipe, missing-anchor pipe, and a sourced vehicle with valid/invalid contact metadata. Deliberate failure injection must make the gate fail.

## Horizontal overlap and clearance pass

Register every placement with a footprint/clearance volume, semantic class, owner, page, and stable ID. Place in dependency order: ground and masses; road/sidewalk boundaries; gameplay-bound cover and volumes; attached utilities; sourced GLBs; background.

Use a uniform-grid AABB broadphase for insertion-scale speed. For candidate pairs, run OBB separating-axis tests or segment/volume tests; use triangle-level queries only for unresolved candidates. Resolve only displaceable pairs with a bounded minimum-translation attempt. Gameplay-bound objects, structural hosts, cover anchors, kill-zone closures, objective-route elements, and semantic volumes are non-displaceable: report the conflict and return it to authoring.

The allow-list is semantic and named, never a regex escape hatch. Valid pairs may include a trim/reveal over its host, glazing within a frame, a declared beam-to-socket attachment, a deliberate stack, or an explicitly approved construction layer. Each allowed pair records purpose, host/child IDs, expected penetration range, and source plan entry. Everything else is an unexplained conflict.

Emit `overlap-report.json` containing pair IDs, zone/page, footprint/clearance volumes, narrowphase result, penetration depth, contact point, classification (`undeclared`, `allowlist_violation`, `unresolvable_non_displaceable`, or resolved), solver history, and deterministic debug captures. Zero unexplained or unresolvable conflicts is required.

## Attachment and utility procedure

Author host sockets before child utilities. A beam, pipe, cable tray, canopy, sign, ladder, stair, or service run must have named endpoints and a termination class: structural support, equipment connection, facade penetration, ground support, or deliberate suspended contract. Generate the child from the endpoints, then validate endpoint distance, parent existence, host support, and clearance. Never draw a long line between buildings and repair its intersections later.

For repeated modules, generate from a frame/rail with bounded variation. Snap dimensions and orientations to the frame; never place free instances one-by-one if the family can emit them from one plan record.

## Gate ownership and reports

| Gate | Owns | Must not own | Blocking artifact |
|---|---|---|---|
| Calibration | human/asset dimensions and traversability | material quality or combat tactics | `calibration-report.json` |
| Contact | vertical support and suspension | horizontal interpenetration | `contact-report.json` |
| Overlap | horizontal conflicts and clearances | camera judgment or semantic redesign | `overlap-report.json` |
| Attachment | host/socket contracts | arbitrary decorative density | attachment section of overlap/contact report |

## References

[1]: https://github.com/gkjohnson/three-mesh-bvh "three-mesh-bvh spatial queries"
[2]: https://github.com/StarKnightt/night-street "night-street contact and placement patterns"
[3]: https://github.com/donmccurdy/glTF-Transform "glTF-Transform optimization and asset processing"
