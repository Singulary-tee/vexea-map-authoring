# Camera Composition and Ox Alpha Critic Loop

## Load this reference when

Load this file after contact, overlap, scale, architecture-depth, and PvE-space checks are green. Use it to prove the slice reads from the player and from fixed forensic views; do not use image judgment to excuse a red world-space gate.

## Fixed camera suite

Capture the same named views on every meaningful change:

| View | Purpose |
|---|---|
| Site/top and orthographic | Expose footprint overlap, empty/overfull zones, route graph, and flatness. |
| Side/section | Expose paper facades, floating beams, missing depth, grade changes, and roof/side closure. |
| Player eye-level route | Test scale, road/sidewalk relationship, cover, route cues, and foreground contact. |
| Insertion view | Establish the first decision, readable destination, and environmental family. |
| Mid-route/pressure view | Test cover/exposure rhythm, drone pressure space, and background separation. |
| Plant/vertical-anchor view | Test height variance, service access, silhouettes, and vertical counterplay. |
| Security threshold | Test surveillance, kill-zone closure, practical access, and route narrowing. |
| Objective approach | Test the far-end destination, final cover, objective readability, and 8-second/3-m semantics. |

Keep camera transforms, viewport, render settings, and seeds stable. Store the camera manifest and scene hash with the capture bundle.

## Depth bands

Assign every visible object to a purpose-driven band: foreground route edge, midground encounter/cover, background landmark/working occupancy, or atmospheric termination. Each object must have a reason to be in its band: route cue, tactical decision, functioning facility, landmark, or atmosphere. Remove objects that cannot be read as one of those at the intended distance.

Measure projected bounds and record occupancy, depth order, silhouette separation, crop, and landmark identity. Avoid a broad pile of small objects in the background; a smaller number of readable masses with distinct silhouettes creates more depth than a dense melted cluster. Use occlusion and culling to remove unreadable distant detail only after world-space gates pass.

A beauty frame cannot be the only evidence. The forensic suite must run with fog/atmosphere disabled or reduced so hidden floaters, overlaps, paper planes, and scale errors remain visible. Final presentation captures may use the selected HDRI, exposure, fog, and practical light treatment, but the same objects must pass the forensic suite.

## Critic request format

Give Ox Alpha one bounded question per review. Include:

1. What changed, the owning procedure, and what must not change.
2. Fixed capture paths and the structural reports that accompany them.
3. The suspected visible root cause, not a list of symptoms.
4. A request for the highest-return diagnosis and an implementation method tied to the bench.
5. Required evidence and a binary `ACCEPT`, `REVISE`, or `REJECT` decision.

A numeric score alone is invalid. `REVISE` means the slice remains below the gate. Repeated feedback on the same root cause is a hard stop: return to the owning plan/grammar stage instead of adding micro-detail. Never ask the critic to approve a semantic drift or a bypass of deterministic gates.

## Critic evidence bundle

Store `critic-request.json`, prompt/version, model ID, response, raw response, capture hashes, structural-report hashes, and the final normalized verdict. Keep any proposed threshold labeled `PROPOSED_TUNABLE` until calibrated from the target browser.

## Visual promotion rules

Promote a change only when it improves the intended camera-visible problem without introducing a new contact, overlap, scale, depth, semantic, PvE, or performance failure. Do not compare candidates by mean pixels alone. Preserve the source capture, candidate capture, changed placement IDs, and a short root-cause decision.

## References

[1]: https://github.com/StarKnightt/sedona-sunset "Sedona Sunset deterministic visual gates"
[2]: https://github.com/majidmanzarpour/threejs-game-skills "Three.js game-authoring visual scorecard"
[3]: https://github.com/nvpro-samples/gl_occlusion_culling "Batched visibility and bounding-box culling principles"
