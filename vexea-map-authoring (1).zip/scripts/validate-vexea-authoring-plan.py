#!/usr/bin/env python3
"""Validate a deterministic VEXEA slice plan before geometry emission.

The validator intentionally checks plan structure and semantic ownership only. It
never edits the plan and never treats an absent optional field as permission to
invent geometry.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict, deque
from pathlib import Path


REQUIRED_TOP = {"schemaVersion", "ledgerHash", "slice", "zones", "connectors", "placements"}
REQUIRED_SLICE = {"id", "zoneIds", "connectorIds"}
REQUIRED_ZONE = {"id", "role", "bounds", "pageId"}
REQUIRED_CONNECTOR = {"id", "from", "to", "role", "pageId"}
REQUIRED_PLACEMENT = {"id", "kind", "owner", "pageId", "supportClass"}


def issue(code: str, message: str, item: str | None = None) -> dict:
    result = {"code": code, "message": message}
    if item is not None:
        result["item"] = item
    return result


def require_keys(obj: object, keys: set[str], label: str, issues: list[dict]) -> None:
    if not isinstance(obj, dict):
        issues.append(issue("not_object", f"{label} must be an object"))
        return
    for key in sorted(keys - obj.keys()):
        issues.append(issue("missing_key", f"{label} is missing required key {key!r}"))


def as_ids(values: object, label: str, issues: list[dict]) -> list[str]:
    if not isinstance(values, list) or not all(isinstance(item, str) and item for item in values):
        issues.append(issue("invalid_ids", f"{label} must be a non-empty list of non-empty strings"))
        return []
    return values


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("plan", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    try:
        plan = json.loads(args.plan.read_text())
    except Exception as exc:  # noqa: BLE001
        print(f"cannot read plan: {exc}", file=sys.stderr)
        return 2

    issues: list[dict] = []
    if not isinstance(plan, dict):
        issues.append(issue("not_object", "plan root must be an object"))
        plan = {}
    for key in sorted(REQUIRED_TOP - plan.keys()):
        issues.append(issue("missing_key", f"plan is missing required key {key!r}"))
    require_keys(plan.get("slice"), REQUIRED_SLICE, "slice", issues)

    zones = plan.get("zones", [])
    connectors = plan.get("connectors", [])
    placements = plan.get("placements", [])
    if not isinstance(zones, list):
        issues.append(issue("invalid_zones", "zones must be a list"))
        zones = []
    if not isinstance(connectors, list):
        issues.append(issue("invalid_connectors", "connectors must be a list"))
        connectors = []
    if not isinstance(placements, list):
        issues.append(issue("invalid_placements", "placements must be a list"))
        placements = []

    seen: dict[str, str] = {}
    zone_ids: set[str] = set()
    page_ids: set[str] = set()
    roles: dict[str, str] = {}
    for zone in zones:
        zid = zone.get("id") if isinstance(zone, dict) else None
        require_keys(zone, REQUIRED_ZONE, f"zone {zid or '<unknown>'}", issues)
        if isinstance(zone, dict) and isinstance(zid, str):
            if zid in seen:
                issues.append(issue("duplicate_id", f"ID already used by {seen[zid]}", zid))
            seen[zid] = "zone"
            zone_ids.add(zid)
            page = zone.get("pageId")
            if isinstance(page, str):
                page_ids.add(page)
            role = zone.get("role")
            if isinstance(role, str):
                if role in roles:
                    issues.append(issue("duplicate_role", f"zone role {role!r} already belongs to {roles[role]}", zid))
                roles[role] = zid
            bounds = zone.get("bounds")
            if not isinstance(bounds, list) or len(bounds) != 4 or not all(isinstance(v, (int, float)) for v in bounds):
                issues.append(issue("invalid_bounds", "zone bounds must be [minX,minZ,maxX,maxZ] numbers", zid))

    graph: dict[str, set[str]] = defaultdict(set)
    connector_ids: set[str] = set()
    for connector in connectors:
        cid = connector.get("id") if isinstance(connector, dict) else None
        require_keys(connector, REQUIRED_CONNECTOR, f"connector {cid or '<unknown>'}", issues)
        if isinstance(connector, dict) and isinstance(cid, str):
            if cid in seen:
                issues.append(issue("duplicate_id", f"ID already used by {seen[cid]}", cid))
            seen[cid] = "connector"
            connector_ids.add(cid)
            src, dst = connector.get("from"), connector.get("to")
            if src not in zone_ids or dst not in zone_ids:
                issues.append(issue("dangling_connector", "connector endpoints must reference declared zones", cid))
            else:
                graph[src].add(dst)
                graph[dst].add(src)
            if not isinstance(connector.get("pageId"), str):
                issues.append(issue("missing_page", "connector needs a pageId", cid))

    placement_ids: set[str] = set()
    for placement in placements:
        pid = placement.get("id") if isinstance(placement, dict) else None
        require_keys(placement, REQUIRED_PLACEMENT, f"placement {pid or '<unknown>'}", issues)
        if isinstance(placement, dict) and isinstance(pid, str):
            if pid in seen:
                issues.append(issue("duplicate_id", f"ID already used by {seen[pid]}", pid))
            seen[pid] = "placement"
            placement_ids.add(pid)
            if not isinstance(placement.get("owner"), str) or not placement["owner"]:
                issues.append(issue("missing_owner", "placement owner must be a stable semantic or family ID", pid))
            if not isinstance(placement.get("pageId"), str) or not placement["pageId"]:
                issues.append(issue("missing_page", "placement needs a pageId", pid))
            support = placement.get("supportClass")
            if support not in {"GROUNDED", "SUPPORTED", "SUSPENDED"}:
                issues.append(issue("invalid_support_class", "supportClass must be GROUNDED, SUPPORTED, or SUSPENDED", pid))
            if support == "SUSPENDED":
                contract = placement.get("anchorContract")
                if not isinstance(contract, dict) or not contract.get("hostIds") or not contract.get("anchorPoints"):
                    issues.append(issue("missing_anchor_contract", "SUSPENDED placement needs hostIds and anchorPoints", pid))
            if placement.get("kind") in {"mass", "building", "facade"} and not placement.get("depthMeters"):
                issues.append(issue("missing_depth", "architectural mass needs positive depthMeters", pid))

    slice_obj = plan.get("slice", {})
    if isinstance(slice_obj, dict):
        requested_zones = set(as_ids(slice_obj.get("zoneIds"), "slice.zoneIds", issues))
        requested_connectors = set(as_ids(slice_obj.get("connectorIds"), "slice.connectorIds", issues))
        if requested_zones and not requested_zones.issubset(zone_ids):
            issues.append(issue("slice_dangling_zone", "slice references a zone not in zones"))
        if requested_connectors and not requested_connectors.issubset(connector_ids):
            issues.append(issue("slice_dangling_connector", "slice references a connector not in connectors"))
        if requested_zones:
            start = next(iter(requested_zones))
            reached = {start}
            queue = deque([start])
            while queue:
                current = queue.popleft()
                for neighbor in graph[current]:
                    if neighbor in requested_zones and neighbor not in reached:
                        reached.add(neighbor)
                        queue.append(neighbor)
            if reached != requested_zones:
                issues.append(issue("disconnected_slice", f"slice zone graph is disconnected: reached {sorted(reached)}, requested {sorted(requested_zones)}"))

    report = {
        "plan": str(args.plan),
        "schemaVersion": plan.get("schemaVersion"),
        "pass": not issues,
        "counts": {"zones": len(zones), "connectors": len(connectors), "placements": len(placements), "pages": len(page_ids)},
        "issues": issues,
    }
    output = json.dumps(report, indent=2) + "\n"
    if args.report:
        args.report.write_text(output)
    print(output, end="")
    return 0 if not issues else 1


if __name__ == "__main__":
    raise SystemExit(main())
