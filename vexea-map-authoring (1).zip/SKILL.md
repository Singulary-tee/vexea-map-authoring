---
name: vexea-map-authoring
description: >
  Author, rebuild, and deliver VEXEA Three.js cooperative-PvE maps without spatial-quality regression. Use for reading VEXEA architecture/gameplay truth, selecting and rebuilding a player-scale vertical slice, choosing procedural versus sourced-GLB versus PBR treatments, validating scale/contact/overlap/depth/cover/verticality/composition/performance, involving Ox Alpha in critic mode, and running the final export/runtime/mobile/build gates.
---

# VEXEA Map Authoring

Use this skill as the **director workflow** for VEXEA map work. Reuse the existing map-authoring bench, semantic export, portable Blender/GLB preparation, capture, runtime, and regression systems. Do not restart from an empty scene and do not continue haphazardly from a visually rejected frame.

## Non-negotiable operating rules

1. **Read truth before editing.** Load `references/vexea-contract-and-ledger.md` and read `ARCHITECTURE.md`, `GAMEPLAY.md`, `GAMEMODE_CONFIG.md`, the current gameplay-first export, `industrial-grammar.md`, and the environment plan. Hash the sources in an authoring ledger.
2. **Preserve gameplay truth.** Keep the existing VEXEA zones, connectors, drone roles, spawn/kill semantics, surveillance/destructible cues, commander cadence, objective semantics, player contract, and runtime/export separation. Visual dressing explains semantic records; it does not silently rewrite them.
3. **Work slice-first.** Select two adjacent zones and their connector. Freeze a hashable slice contract and semantic baseline before visual dressing. Do not dress the rest of the campus until the slice bundle passes and Ox Alpha accepts it.
4. **Calibrate to the 1.8 m player.** Use actual repository capsule and eye-height constants. Build one persistent calibration fixture and block unknown-scale assets. Vehicles and machinery are sourced prepared GLBs; check scale, contact, provenance, LOD, and context—never author procedural tire internals.
5. **Author volumes and systems before polish.** Ground, road/sidewalk, real-depth masses, route boundaries, deliberate cover, and vertical roles precede props, materials, atmosphere, and background.
6. **Run world-space gates.** Measure contact, attachments, overlap, clearance, scale, traversal, facade depth, vertical support, and semantic bindings. Do not hide defects with fog, framing, culling, or lower LOD.
7. **Use procedural grammar, not primitive filler.** Every promoted family needs profile, thickness, joints, support/termination, material slots, seeded variation, distance tiers, and evidence. Visible boxes/cylinders standing in for finished buildings, roads, utilities, or cover block promotion.
8. **Tie spaces to PvE decisions.** Cover, exposure, retreats, routes, deployment/kill-zone closure, surveillance, and verticality must serve actual VEXEA drone behavior and player counterplay.
9. **Preserve quality during optimization.** Use LOD, paging, culling, instancing, merging/batching, texture/material discipline, and measured browser budgets. Do not turn the scene into ugly low-poly substitutes to make metrics pass.
10. **Require Ox Alpha.** Use Ox Alpha at architecture consignment, slice evidence review, and final adversarial release review. A score alone is invalid. `REVISE` blocks promotion; repeated feedback on one root cause returns work to its owning stage.

## Required workflow

### 1. Establish the ledger and slice contract

Load the contract reference. Write `authoring-ledger.json` and `slice-contract.json` with source hashes, fixed constants, selected zone/connector subgraph, roles, route/objective/deployment semantics, cover/vertical obligations, camera suite, and reuse table. Export and hash the semantic baseline. Stop on missing or conflicting source truth.

### 2. Build the calibration fixture

Construct and save the 1.8 m human, player capsule, eye datum, clearance ring, metric grid, door/stair/cover gauges, vehicle scale board, and camera marker. Emit `calibration-report.json`. Run player-height, top-down, and section captures. Block any asset lacking units, dimensions, uniform transform, contact metadata, provenance, or a passing manifest.

### 3. Compile a deterministic spatial plan

Write `slice-plan.json` rather than scattering ad hoc Three.js placements. Give each zone, connector, mass, opening, module, utility, asset, support, attachment, page, gameplay binding, and camera-relevant element a stable ID and owner. Run the plan/graph validator before geometry emission.

Use the rail: footprint -> void/court -> volume -> openings/insets -> connectors/access -> exposed-boundary ownership -> module placement -> geometry emission. Reject unresolved ownership, endpoints, footprint conflicts, missing page IDs, and unbound semantic records.

### 4. Author the spatial foundation

Create ground, road centerlines, segmented sidewalks, curbs, drainage, hardstands, ramps, and grade transitions. Place architectural volumes with front/side/rear/roof/ground interfaces, real depth, openings, service access, and roof/parapet termination. Assign low/mid/high height roles and at least one meaningful player-usable vertical relationship. Load `references/industrial-grammar-and-architecture.md`.

### 5. Author PvE space before decoration

Create the combat-space matrix, cover bindings, route probes, deployment/kill-zone explanations, surveillance cues, and verticality report. Use `references/pve-space-and-cover.md`. Treat gameplay-bound objects as non-displaceable. Do not add random clutter to fill empty space.

### 6. Run scale, contact, overlap, and depth gates

Load `references/scale-contact-overlap.md`. Run separate ownership gates:

- **Calibration/scale:** compare assets and placements with the fixture and capsule; sweep all intended traversable doors, corridors, stairs, and routes.
- **Contact/attachment:** freeze ground; probe grounded/supported objects; require host/socket contracts for suspended utilities; classify and report floating/sunk/unresolved objects.
- **Overlap/clearance:** broadphase placement AABBs, narrowphase OBB/segment/triangle tests, semantic allow-list, bounded solver for displaceable pairs, hard failure for gameplay/structural conflicts.
- **Architecture depth:** reject paper facades, missing closures, unsupported beams, and unowned service modules.

Emit `calibration-report.json`, `contact-report.json`, `overlap-report.json`, `architecture-audit.json`, and deterministic fixture/failure-injection logs. Run `scripts/validate-vexea-scene-gates.py` when available. Any red gate sends work to its owner; never patch symptoms through camera or fog.

### 7. Capture the forensic camera suite

Load `references/camera-composition-and-critic.md`. Capture named site/top, side/section, player-route, insertion, mid-route, pressure, plant/vertical, security-threshold, and objective-approach views. Use fog-disabled forensic presets plus final presentation captures. Record depth bands, projected bounds, occupancy, silhouette separation, crop, landmark identity, and background simplification. A technically present but unreadable object does not earn inclusion.

### 8. Compile performance after quality is coherent

Load `references/performance-and-delivery.md`. Assign pages and runtime classes. Apply LOD, merge/instance/batch choices, texture/material discipline, and culling based on measured bottlenecks. Emit per-page renderer/backend, draw, triangle, texture-memory, frame-time, visibility, LOD, and visual-preservation evidence. Keep all thresholds labeled `PROPOSED_TUNABLE` until calibrated on the target browser.

### 9. Ask Ox Alpha and promote only accepted evidence

Send one focused request with the fixed capture suite, structural reports, hashes, changed IDs, suspected root cause, implementation hypothesis, and do-not-change boundaries. Ask for diagnosis, required evidence, and `ACCEPT`/`REVISE`/`REJECT`. Persist the prompt, model, raw response, normalized response, capture hashes, and report hashes. `REVISE` or `REJECT` blocks promotion.

### 10. Run delivery gates and decide expansion

Run `scripts/run-vexea-authoring-gates.sh` or the repository’s exact current equivalent. The bundle must include source/provenance, ledger, slice contract, plan, semantic baseline/diff, calibration, contact, overlap, architecture, PvE, verticality, camera, performance, critic, gameplay/export, runtime, mobile, Blender/GLB, and build evidence. Only a green bundle plus Ox Alpha acceptance permits slice promotion or expansion to the next zone pair.

## Bundled resources

Load only the reference needed for the current stage. Keep the core workflow above in context and use these files for details:

- `references/vexea-contract-and-ledger.md` — project truth, hashes, slice selection, semantic baseline, expansion gate.
- `references/scale-contact-overlap.md` — calibration, GLB placement admission, grounding, support contracts, overlap/clearance, fixtures.
- `references/industrial-grammar-and-architecture.md` — treatment choice, volumetric buildings, roads, procedural family grammar, height rhythm, primitive rejection.
- `references/pve-space-and-cover.md` — combat-space matrix, cover, drone roles, deployment/kill-zone closure, surveillance, vertical play.
- `references/camera-composition-and-critic.md` — fixed camera suite, depth bands, forensic captures, Ox Alpha review and stop conditions.
- `references/performance-and-delivery.md` — LOD, paging, culling, instancing, merging/batching, metrics, visual-preservation and release order.
- `scripts/validate-vexea-authoring-plan.py` — validate plan schema, ownership, attachments, semantic bindings, and stable IDs.
- `scripts/validate-vexea-scene-gates.py` — aggregate/contact/overlap/depth/vertical/PvE report gates and deliberate failure fixtures.
- `scripts/run-vexea-authoring-gates.sh` — run the fixed fail-closed authoring and delivery sequence.

## Hard stop conditions

Stop and return to the owning stage when a contract is ambiguous; the selected slice is not representative; an object lacks stable ownership; a facade is a plane; a utility lacks endpoints; a visible primitive is unfinished; a prop floats/sinks/intersects; a vehicle is mis-scaled or ungrounded; cover has no tactical role; verticality has no support or gameplay purpose; background objects melt into unreadable density; semantic export drifts; a report is missing; a proposed threshold is treated as fact; performance is solved by quality degradation; or Ox Alpha returns `REVISE`/`REJECT`.

Never deliver a map because the build is green, the pixel metric changed, a sourced asset looks good in isolation, or the authoring bench starts. Deliver only the complete evidence bundle.
