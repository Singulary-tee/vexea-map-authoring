#!/usr/bin/env python3
"""Aggregate VEXEA authoring reports and run a small fail-closed self-test.

This script does not pretend to discover geometry defects from prose. Geometry
passes must emit machine-readable reports keyed by stable IDs; this tool checks
those reports and blocks promotion when a required report is absent or red.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REQUIRED_REPORTS = {
    "calibration": "calibration-report.json",
    "contact": "contact-report.json",
    "overlap": "overlap-report.json",
    "architecture": "architecture-audit.json",
    "pve": "combat-space-matrix.json",
    "verticality": "verticality-report.json",
    "camera": "camera-suite-report.json",
    "performance": "render-budget-report.json",
    "semantic": "semantic-diff-report.json",
}


def load(path: Path) -> dict:
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def report_is_green(name: str, value: dict) -> tuple[bool, str]:
    if value.get("pass") is False or value.get("passed") is False:
        return False, f"{name} explicitly reports pass=false"
    issues = value.get("issues", [])
    failures = value.get("failures", [])
    unresolved = value.get("unresolved", [])
    conflicts = value.get("conflicts", [])
    red = [item for item in (issues, failures, unresolved, conflicts) if isinstance(item, list) and item]
    if red:
        return False, f"{name} contains non-empty failure fields"
    if "pass" not in value and "passed" not in value:
        return False, f"{name} has no explicit pass/passed field"
    return True, "green"


def self_test() -> bool:
    good = {"pass": True, "issues": [], "failures": [], "unresolved": [], "conflicts": []}
    bad = {"pass": False, "issues": [{"id": "lifted-prop"}]}
    ok, _ = report_is_green("fixture-good", good)
    fail, _ = report_is_green("fixture-bad", bad)
    return ok and not fail


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reports-dir", type=Path)
    parser.add_argument("--report", action="append", type=Path, default=[])
    parser.add_argument("--output", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        result = {"self_test": self_test(), "failure_injection": "red report must be rejected"}
        print(json.dumps(result, indent=2))
        return 0 if result["self_test"] else 1

    report_paths: dict[str, Path] = {}
    if args.reports_dir:
        for name, filename in REQUIRED_REPORTS.items():
            report_paths[name] = args.reports_dir / filename
    for path in args.report:
        report_paths[path.stem.replace("-report", "").replace("_report", "")] = path

    entries = []
    errors = []
    for name, path in sorted(report_paths.items()):
        if not path.exists():
            errors.append({"name": name, "code": "missing_report", "path": str(path)})
            continue
        try:
            value = load(path)
            passed, reason = report_is_green(name, value)
            entry = {"name": name, "path": str(path), "pass": passed, "reason": reason}
            if not passed:
                errors.append(entry)
            entries.append(entry)
        except Exception as exc:  # noqa: BLE001
            errors.append({"name": name, "path": str(path), "code": "invalid_json", "reason": str(exc)})

    result = {
        "pass": not errors and set(report_paths) >= set(REQUIRED_REPORTS),
        "required_reports": REQUIRED_REPORTS,
        "checked": entries,
        "failures": errors,
        "behavior": "fail-closed: missing, malformed, explicitly red, or structurally incomplete reports block promotion",
    }
    text = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
