# Performance-Preserving Compilation and Delivery

## Load this reference when

Load this file after the slice is spatially valid and visually coherent, or when a measured runtime bottleneck appears. Performance work must preserve the visual contract and must not be used to conceal geometry defects.

## Runtime treatment matrix

| Element | Preferred strategy | Evidence |
|---|---|---|
| Static architectural/page geometry | Merge compatible geometry by page/material when draw collapse is measured to help | Before/after draw, triangle, memory, and silhouette captures |
| Repeated identical modules | Instancing | Instance count, batch grouping, projected-size capture |
| Compatible editable detail | Batched geometry only when backend measurement proves benefit | Mutation/identity requirements and draw report |
| Complex sourced GLB | Blender cleanup, packed materials, LOD chain, optional glTF optimization | Prepared manifest, source/provenance, LOD silhouettes |
| Distant background | Spatial page, frustum/occlusion approximation, projected-error LOD, or cull | Page visibility and landmark-read capture |
| Unique gameplay/interaction object | Preserve stable identity and semantic binding | Runtime bridge and gameplay contract report |

Use the existing portable Blender path for sourced assets. Keep source and prepared files distinct, record licenses, and validate manifests. Use glTF-Transform only as an optional reproducible post-process when it preserves materials, transforms, stable metadata, and LOD evidence; never replace the validated Blender export blindly.

## Spatial compilation

Assign each plan element a spatial page and runtime class before export. Pages have finite bounds, stable IDs, load/draw ownership, and visibility relationships. Avoid a single monolithic scene when the map is large; page boundaries should follow zones/connectors and support the authoring slice. Preserve the far-end objective and gameplay semantic identity across pages.

Start with frustum/page culling and measured projected-size LOD. Add occlusion work only when a profile identifies a bottleneck. A culling system may remove distant unreadable detail, but it may not exclude objects from contact/overlap/depth audits. Keep forensic QA geometry independent from final view culling.

## Measurement

Record renderer/backend identity, initialization time, frame time, draw items/calls, triangles in view, texture memory, visible pages, LOD distribution, and capture dimensions. Run two consecutive measurements with the same seed and camera set. Keep budgets as `PROPOSED_TUNABLE` until measured against the target browser/device.

Per-page reports should include:

- LOD0/LOD1/LOD2 triangle and material counts.
- Draw calls or draw-item count by family/page.
- Texture dimensions, format, and memory estimate.
- Page visibility and load timing.
- Camera-visible projected error and silhouette preservation.
- The named remedy for every budget breach.

A successful optimization must have a visual-preservation capture. If a change makes a building, vehicle, cover object, road edge, or landmark less readable, reject the optimization even if numbers improve. Do not solve a load stall by turning authored construction into cubes, cylinders, textureless slabs, or low-detail assets that violate the quality floor.

## Delivery order

Run the current repository’s exact gates without replacing commands: lint; export bench; map bridge; gameplay contract; canonical capture and pixels; spatial QA; map bench; smoke/interaction/mobile/readiness/runtime/slice/core/benchmark; Blender/GLB manifest validation; and build. Add the new plan/contact/overlap/depth/vertical/PvE/camera/performance reports to an artifact manifest.

Verify that presentation-only sourced assets do not silently alter the active gameplay export asset contract. Verify source licenses and credits. Keep runtime and presentation layers separate.

## References

[1]: https://github.com/donmccurdy/glTF-Transform "glTF-Transform asset optimization"
[2]: https://github.com/nvpro-samples/gl_occlusion_culling "Batched occlusion-culling principles"
[3]: https://github.com/linegel/threejs-complete-set-of-skill "Procedural compilation and instancing patterns"
[4]: https://github.com/StarKnightt/sedona-sunset "Measured rendering and scene gates"
